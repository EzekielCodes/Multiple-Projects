package logica;

public class Connectie{
    private int stadOne = 0;
    private int stadTwo = 0;




    public Connectie(int stadOne, int stadTwo){
        this.stadOne = stadOne;
        this.stadTwo = stadTwo;
    }


    public int getStadOne() {
        return stadOne;
    }

    public int getStadTwo() {
        return stadTwo;
    }
}

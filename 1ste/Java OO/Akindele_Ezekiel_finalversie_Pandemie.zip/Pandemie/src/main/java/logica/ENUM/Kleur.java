package logica.ENUM;

public enum Kleur {
    GEEL,BLAUW,BRUIN,WIT,ZWART,ROOD
}

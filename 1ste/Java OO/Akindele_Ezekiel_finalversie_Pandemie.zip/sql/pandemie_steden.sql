-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: localhost    Database: pandemie
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `steden`
--

DROP TABLE IF EXISTS `steden`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `steden` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `naam` varchar(45) NOT NULL,
  `kleur` enum('GEEL','ROOD','BLAUW','ZWART') NOT NULL,
  `x` int NOT NULL,
  `y` int NOT NULL,
  `onderzoekscentrum` tinyint(3) unsigned zerofill NOT NULL DEFAULT '000' COMMENT 'onderzoekscentrum mogelijk bij de start',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `steden`
--

LOCK TABLES `steden` WRITE;
/*!40000 ALTER TABLE `steden` DISABLE KEYS */;
INSERT INTO `steden` VALUES (1,'Londen','BLAUW',349,579,000),(2,'Essen','BLAUW',456,592,000),(3,'Parijs','BLAUW',385,650,000),(4,'Madrid','GEEL',306,801,000),(5,'Milaan','BLAUW',476,716,000),(6,'St. Petersburg','ZWART',758,387,000),(7,'Moskou','ZWART',857,481,000),(8,'Istanbul','GEEL',743,794,000),(9,'Algiers','GEEL',395,869,000),(10,'Brussel','BLAUW',415,608,001),(11,'Oslo','ROOD',495,394,000),(12,'Tromsø','ROOD',609,80,000),(13,'Stockholm','ROOD',596,406,000),(14,'Helsinki','ROOD',680,368,000),(15,'Sofia','ZWART',669,759,000),(16,'Tallinn','ROOD',699,418,000),(17,'Riga','ZWART',677,462,000),(18,'Minsk','ZWART',725,542,000),(19,'Kiev','ZWART',761,613,000),(20,'Athene','GEEL',675,846,000),(21,'Boekarest','ZWART',701,728,000),(22,'Reykjavik','ROOD',71,260,000),(23,'Wenen','BLAUW',569,658,000),(24,'Warschau','ZWART',624,570,000),(25,'Rome','GEEL',528,775,000);
/*!40000 ALTER TABLE `steden` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-06-04 19:03:13

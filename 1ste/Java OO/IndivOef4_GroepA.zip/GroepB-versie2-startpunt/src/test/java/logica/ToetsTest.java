package logica;

import org.junit.jupiter.api.Test;

import javax.swing.*;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

/**
 * IndivOef4_GroepB : ToetsTest
 *
 * @author kristien.vanassche
 * @version 9/06/2021
 */

class ToetsTest {
    private ImageIcon icon;

    public ToetsTest() {
        icon = new ImageIcon("./images/default.jpg");
    }

    @Test
    public void testLetter() {
        Toets t = new Letter('A');
        assertEquals("A", t.getTekst());
        assertNull(t.getAfbeelding());
        assertEquals("A", t.toString());
    }

    @Test
    public void testCijfer() {
        Toets t = new Cijfer(1, new ImageIcon());
        assertEquals("1", t.getTekst());
        assertNotNull(t.getAfbeelding());
        assertEquals("1", t.toString());
        assertThrows(IllegalArgumentException.class, ()-> new Cijfer(-1));
        assertThrows(IllegalArgumentException.class, ()-> new Cijfer(10));
    }

    @Test
    public void testLeesteken() {
        Toets t = new Leesteken(',', "komma", "XXX");
        assertEquals(",", t.getTekst());
        assertNull(t.getAfbeelding());
        assertTrue(t.toString().contains(","));
        assertTrue(t.toString().startsWith("komma"));
        assertTrue(t.toString().endsWith("XXX"));
    }

    @Test
    public void testEmoticonMissingData() {
        assertThrows(IllegalArgumentException.class, () -> new Emoticon("XX", "XX", null));
        assertThrows(IllegalArgumentException.class, () -> new Emoticon("", "XX", icon));
        assertThrows(IllegalArgumentException.class, () -> new Emoticon("XX", "", icon));
    }

    @Test
    public void testEmoticon2() {
        Toets t = new Emoticon("(§°°§)", "myEmoticon", icon);
        assertEquals("(§°°§)", t.getTekst());
        assertNotNull(t.getAfbeelding().getImage());
        assertTrue(t.toString().contains("(§°°§)"));
        assertTrue(t.toString().endsWith("[myEmoticon]"));

        IPictogram pictogram = (Emoticon) t;
        assertEquals("(§°°§)", pictogram.getCode());
        assertEquals("myEmoticon", pictogram.getNaam());
        assertEquals(icon, pictogram.getAfbeelding());
    }

    /*
    @Test
    public void testEmoticonSort() {
        Emoticon[] rij = new Emoticon[] {
                new Emoticon(".", "C", icon),
                new Emoticon(".", "B", icon)
        };
        Arrays.sort(rij);
        assertEquals("C", rij[1].getNaam());
        assertEquals("B", rij[0].getNaam());
    }
    */
}
package logica.Enum;

public enum Categorie {
    KLEINE_LETTER,HOOFLETTER,CIJFER,LEESTEKEN,EMOOTICON
}

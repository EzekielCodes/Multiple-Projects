package logica;

import com.sun.jdi.Field;

import javax.swing.*;

/**
 * IndivOef4_GroepB : IPictogram
 *
 * @author kristien.vanassche
 * @version 31/05/2021
 */
public interface IPictogram  {
    String getCode();
    String getNaam();
    ImageIcon getAfbeelding();
}

package logica;

import javax.swing.*;

/**
 * IndivOef4_GroepA : Toets
 *
 * @author kristien.vanassche
 * @version 10/06/2021
 */
public abstract class Toets {
    private String tekst;
    private ImageIcon afbeelding;

    public Toets(String t){
        this.tekst = t;
    }

    public Toets(String t ,  ImageIcon beeld){
        if(beeld == null || tekst == null ){
            throw new IllegalArgumentException ("");
        }
        else {
            this.tekst = t;
            this.afbeelding = beeld;
        }

    }

    public String getTekst() {
        return tekst;
    }

    public ImageIcon getAfbeelding() {
        return afbeelding;
    }

    @Override
    public String toString() {
        return tekst;
    }
}

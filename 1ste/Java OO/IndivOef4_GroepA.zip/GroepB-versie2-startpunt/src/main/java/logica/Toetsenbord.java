package logica;
import data.IO;
import logica.Enum.Categorie;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

/**
 * IndivOef4_GroepA : Toetsenbord
 *
 * @author kristien.vanassche
 * @version 10/06/2021
 */
public class Toetsenbord {
    private Categorie c;
    private int aantalKolommen;
    private List<Toets> toetsen;

    public Toetsenbord(Categorie c, int aantalKolommen) throws FileNotFoundException {
       this.toetsen =  getToestenreeks(c);
        this.aantalKolommen = aantalKolommen;

    }

    public Toetsenbord(Categorie c) throws FileNotFoundException {
        this.toetsen =  getToestenreeks(c);
    }


    public List<Toets> getToetsen() {
        return toetsen;
    }

    public int getAantalKolommen() {
        return aantalKolommen;
    }

    public List getToestenreeks(Categorie c) throws FileNotFoundException {

        if(c == Categorie.KLEINE_LETTER){
            ArrayList<Character> x = new ArrayList<Character>();

            for (int i = 'A'; i <= 'Z'; i++) {
                x.add((char) i);
            }
            return x;
         }
            //char[] alphabet = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};
           // ArrayList array = new ArrayList<Toets>();

        else if (c == Categorie.CIJFER){
            Character[] numbers = {'7', '8', '9', '4', '5', '6', '1', '2', '3', '0'};
            List<Character> array = new ArrayList<Character>();
            array.addAll(Arrays.asList(numbers));

            return array;

        }
        else if(c == Categorie.LEESTEKEN){
            List<Toets> tekensList = IO.leesLeestekens("./src/main/resources/", "emoticons.txt");
            return tekensList;

        }
        else if ( c == Categorie.EMOOTICON){
          List<Toets> emoticonList = IO.leesEmoticons("./src/main/resources/", "emoticons.txt");
            return emoticonList;
        }
        else if ( c == Categorie.HOOFLETTER){
            Character[] alphabet = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'L', 'N', '0', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};
            List<Character> array = new ArrayList<Character>();
            array.addAll(Arrays.asList(alphabet));

            return array;
        }

        return null;
    }
}

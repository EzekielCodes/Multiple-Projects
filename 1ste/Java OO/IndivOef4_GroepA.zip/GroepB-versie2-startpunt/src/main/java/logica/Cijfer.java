package logica;
import logica.Toets;

import javax.swing.*;

public class Cijfer extends  Toets{

    public Cijfer(int x){

        super(String.valueOf(x));
        controleCijfer(x);
    }

    public Cijfer(int x , ImageIcon beeld){
        super(String.valueOf(x),beeld);
    }

    public void controleCijfer(int x){
        if (x > 0 && x < 9){
            
        }
        else {
           throw new IllegalArgumentException ("");
        }
    }
}

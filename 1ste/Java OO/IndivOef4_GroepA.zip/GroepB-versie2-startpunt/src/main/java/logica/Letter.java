package logica;
import logica.Toets;
public class Letter extends Toets{

    public Letter(char c){
       super(String.valueOf(c));
    }
}

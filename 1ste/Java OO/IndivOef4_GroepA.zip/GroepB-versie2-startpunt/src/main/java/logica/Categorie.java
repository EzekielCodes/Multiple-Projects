package logica;

/**
 * IndivOef4_GroepA : Categorie
 *
 * @author kristien.vanassche
 * @version 10/06/2021
 */
public enum Categorie {
}

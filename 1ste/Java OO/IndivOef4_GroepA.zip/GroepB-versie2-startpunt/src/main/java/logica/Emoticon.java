package logica;
import javax.swing.*;
import logica.*;
public class  Emoticon extends Toets implements IPictogram{
    String naam;



    public Emoticon(String n, String tekst, ImageIcon beeld){
            super(tekst,beeld);
            this.naam = n;
    }


    @Override
    public String getCode() {
        return super.getTekst();
    }

    @Override
    public String getNaam() {
        return naam;
    }

    @Override
    public ImageIcon getAfbeelding() {
        return super.getAfbeelding();
    }

    @Override
    public String toString() {
        return super.getTekst() + " [" + naam + "] ";
    }

    public int compareTo(Emoticon t){
        return this.naam.compareTo(t.naam);
    }
}

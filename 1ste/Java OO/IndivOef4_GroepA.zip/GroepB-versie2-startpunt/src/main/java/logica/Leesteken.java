package logica;

public class Leesteken extends  Toets{
    private String naam;
    private String beschrijving;

    public Leesteken(char c,String naam, String beschrijving){
        super(String.valueOf(c));
        this.naam = naam;
        this.beschrijving = beschrijving;

    }

    @Override
    public String toString() {
        return naam + " ("  +super.toString() + ") " + beschrijving;
    }
}

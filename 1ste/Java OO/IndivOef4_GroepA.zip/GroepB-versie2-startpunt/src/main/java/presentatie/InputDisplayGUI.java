package presentatie;

import logica.*;
import logica.Enum.Categorie;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.FileNotFoundException;

/**
 * IndivOef4_GroepB : InputDisplayGUI
 *
 * @author kristien.vanassche
 * @version 1/06/2021
 */
public class InputDisplayGUI {
    private JPanel panelMain;
    private JPanel panelIntern;
    private JRadioButton lettersKleinRadioButton;
    private JRadioButton lettersGrootRadioButton;
    private JRadioButton emoticonsRadioButton;
    private JRadioButton cijfersRadioButton;
    private JEditorPane editorPaneInput;
    private JRadioButton leestekensRadioButton;

    private Toetsenbord toetsenbord = new Toetsenbord(Categorie.KLEINE_LETTER, 3);



    public InputDisplayGUI() throws FileNotFoundException {
        editorPaneInput.setContentType("text/html");
        editorPaneInput.setText("Gemaakte keuze:\n");

        try {
            //TODO: initialiseer hier je toetsenbord
        }
        catch (Exception e) {
            JOptionPane.showMessageDialog(null, "ERROR: " + e.getMessage());
        }

        if (toetsenbord == null) {
            JOptionPane.showMessageDialog(null, "Initialiseer je toetsenbord!");
            return;
        }
        else if (toetsenbord.getToetsen() == null) {
            JOptionPane.showMessageDialog(null, "Initialiseer de toetsenlijst van je toetsenbord!");
        }
        setKnoppenGUI();

        //TODO: verzorg hier de event handling voor de radiobuttons
    }

    private void setKnoppenGUI() {
        editorPaneInput.setText("");
        panelIntern.removeAll();

        int aantalkol = toetsenbord.getAantalKolommen();

        if (aantalkol <= 0) {
            aantalkol = (int) Math.sqrt(toetsenbord.getToetsen().size()) + 1;
        }
        panelIntern.setLayout(new GridLayout(0, aantalkol));


        for (Toets toets : toetsenbord.getToetsen()) {
            if (toets != null) {
                JButton button = new JButton(toets.getTekst());
                button.setName(toets.getTekst());

                if (toets instanceof IPictogram) {
                    button.setToolTipText(((IPictogram) toets).getNaam());
                }

                ToolTipManager.sharedInstance().registerComponent(button); //cf. https://stackoverflow.com/questions/21949967/jbutton-dynamic-tooltip-text-not-showing
                ToolTipManager.sharedInstance().setInitialDelay(0);
                ToolTipManager.sharedInstance().setDismissDelay(10000);

                if (toets.getAfbeelding() != null) {
                    Image image = toets.getAfbeelding().getImage();

                    //https://stackoverflow.com/questions/6714045/how-to-resize-jlabel-imageicon
                    image = image.getScaledInstance(20, 20, Image.SCALE_SMOOTH);
                    button.setIcon(new ImageIcon(image));
                    //button.setText("..."); //=> info knop, zie getName()
                    button.setContentAreaFilled(false);
                    button.setBorder(BorderFactory.createLineBorder(Color.white, 2));
                }

                //TODO: verzorg de event handling voor de toetsaanslagen
                button.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        JButton knop = (JButton) e.getSource();
                        verwerk(knop);
                    }
                });

                panelIntern.add(button);
            } else {
                panelIntern.add(new JButton("")); //dummy toets toevoegen
            }

            panelIntern.repaint();
            panelIntern.revalidate();
        }
    }

    //TODO: verzorg hier de event handling voor de toetsaanslagen
    private void verwerk(JButton knop) {
    }

    public static void main(String[] args) throws FileNotFoundException {
        JFrame frame = new JFrame("IndivOef4 - GroepB");
        frame.setContentPane(new InputDisplayGUI().panelMain);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //frame.pack();
        frame.setSize(1300, 500);
        frame.setVisible(true);
    }

    private void createUIComponents() {
        panelIntern = new JPanel();
    }
}

package data;

import logica.Toets;

import java.io.File;
import java.io.FileNotFoundException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class IO {

    public static List<Toets> leesEmoticons(String path, String naam) throws FileNotFoundException {
        List emoticonsList= new ArrayList<>();
        try (Scanner sc = new Scanner(new File(path+naam))) {
            //Quiz quiz = new Quiz("Biertjes");
            while (sc.hasNextLine()) {
                String[] info = sc.nextLine().split("\t");
                emoticonsList.add(info[1]);
                System.out.println("Q: " + info[0] + "\n=> " + info[1] + "\n=> " + info[2]);
            }
        }
        return emoticonsList;
    }

    public static List<Toets> leesLeestekens(String path, String naam) throws FileNotFoundException {
        List leesList= new ArrayList<>();
        try (Scanner sc = new Scanner(new File(path+naam))) {
            //Quiz quiz = new Quiz("Biertjes");
            while (sc.hasNextLine()) {
                String[] info = sc.nextLine().split("\t");
                System.out.println(Arrays.toString(info));

                leesList.add(info[1]);
                System.out.println("Q: " + info[0] + "\n=> " + info[1] + "\n=> " + info[2]);
            }
        }
        return leesList;
    }

}

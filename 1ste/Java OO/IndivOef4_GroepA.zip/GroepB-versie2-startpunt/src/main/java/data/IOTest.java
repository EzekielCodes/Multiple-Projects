package data;

import logica.Emoticon;
import logica.Leesteken;
import logica.Toets;
import logica.Toetsenbord;
import org.junit.jupiter.api.Test;
import presentatie.*;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.image.Raster;
import java.awt.image.WritableRaster;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * IndivOef4_GroepB : IOTest
 *
 * @author kristien.vanassche
 * @version 9/06/2021
 */
class IOTest {
    @Test
    public void testLeesOnbestaandBestand() {
        assertThrows(FileNotFoundException.class, ()->IO.leesLeestekens("./src/main/resources/", "onbestaandBestand"));
    }

    @Test
    void getLeesLeestekens() throws FileNotFoundException {
        List<Toets> toetsen = IO.leesLeestekens("./src/main/resources/", "leestekens.txt");
        assertEquals(6, toetsen.size());
        String[] namen = {"komma", "puntkomma", "punt", "dubbelepunt", "vraagteken", "uitroepteken"};
        String[] tekens = {",", ";", ".", ":", "?", "!"};
        for(int i = 0; i< toetsen.size(); i++)  {
            assertTrue(toetsen.get(i).toString().contains(namen[i]));
            assertTrue(toetsen.get(i).toString().contains(tekens[i]));
            assertTrue(toetsen.get(i).toString().contains("een zin"));
        }
    }

    @Test
    void leesEmoticonsData() throws FileNotFoundException {
        List<Toets> toetsen = IO.leesEmoticons("./src/main/resources/", "emoticons.txt");
        assertEquals(24, toetsen.size());
        assertEquals(":/", toetsen.get(0).getTekst());
        assertEquals("unsure", ((Emoticon)toetsen.get(0)).getNaam());
        assertEquals(":|]", toetsen.get(23).getTekst());
        assertEquals("robot", ((Emoticon)toetsen.get(23)).getNaam());
    }

    @Test
    void leesEmoticonsSort() throws FileNotFoundException {
        List<Toets> toetsen = IO.leesEmoticons("./src/main/resources/", "emoticons.txt");
        assertEquals(":/", toetsen.get(0).getTekst());
        assertEquals(":|]", toetsen.get(23).getTekst());
       // Collections.sort(toetsen);
        assertEquals("O:)", toetsen.get(0).getTekst());
        assertEquals(";-)", toetsen.get(23).getTekst());
    }

    @Test
    void leesEmoticonsAfbeelding() throws IOException {
        List<Toets> toetsen = IO.leesEmoticons("./src/main/resources/", "emoticons.txt");
        for (int i = 0; i < 24; i++) {
            assertNotNull(toetsen.get(i).getAfbeelding());
            assertTrue( toetsen.get(0).getAfbeelding().getImage() instanceof BufferedImage);
        }
    }
}